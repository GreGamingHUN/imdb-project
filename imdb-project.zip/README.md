# imdb-project
imdb beadandó Adatbázisok gyakorlatra

## Setup
 1. Telepítsd a Node.JS-t
 2. Klónozd ezt a git repository-t
 3. Nyisd meg a klónozott mappát terminálban
 4. Rakd fel ezeket a Node modulokat: `express, express-fileupload, ejs, mysql, date-and-time, node-localstorage` (`npm i (modul neve)`)
 5. Importáld be az SQL adatbázist
 6. Ha szükséges állítsd át az adatbázis csatlakozási beállításokat az app.js-ben (19-22. sor)
 7. Futtasd a szervert a `node .` paranccsal

A webszerver a 8080-as porton fut (localhost:8080)
